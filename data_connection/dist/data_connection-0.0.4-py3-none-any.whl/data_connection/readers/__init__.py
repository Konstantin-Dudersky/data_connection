"""Readers examples."""

from . import opcua_client

__all__: list[str] = [
    "opcua_client",
]
